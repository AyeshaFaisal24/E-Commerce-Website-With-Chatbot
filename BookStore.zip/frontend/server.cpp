#include "crow_all.h"
#include <string>

int main() {
    crow::SimpleApp app;

    CROW_ROUTE(app, "/chat").methods("POST"_method)([](const crow::request& req){
        auto body = crow::json::load(req.body);
        if (!body) {
            return crow::response(400);
        }

        std::string prompt = body["prompt"].s();
        std::string response = "This is a response to: " + prompt;  // This is just a placeholder

        crow::json::wvalue result;
        result["response"] = response;
        return result;
    });

    app.port(8080).multithreaded().run();
}
