document.addEventListener('DOMContentLoaded', function() {
    const chatForm = document.getElementById('chatbot-form');
    const userInput = document.getElementById('user-input');
    const chatMessages = document.getElementById('chat-messages');
    const quickSuggestions = document.getElementById('quick-suggestions');
    const closeBtn = document.getElementById('close-chatbot');
    
    // Speech recognition setup
    let recognition;
    try {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        
        recognition.onresult = function(event) {
            const transcript = event.results[0][0].transcript;
            userInput.value = transcript;
            userInput.focus();
        };
        
        recognition.onerror = function(event) {
            console.error('Speech recognition error', event.error);
            addBotMessage("Sorry, I couldn't understand your voice. Please try typing instead.");
        };
    } catch (e) {
        console.log("Speech recognition not supported");
        micBtn.style.display = 'none';
    }
    
    // Event listeners
    chatForm.addEventListener('submit', sendMessage);
    
    quickSuggestions.querySelectorAll('.suggestion-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            userInput.value = this.textContent;
            userInput.focus();
        });
    });
    
    if (micBtn) {
        micBtn.addEventListener('click', toggleSpeechRecognition);
    }
    
    if (closeBtn) {
        closeBtn.addEventListener('click', function() {
            // In a real app, you might minimize the chat instead
            window.location.href = 'main.html';
        });
    }
    
    // Functions
    function sendMessage(e) {
        e.preventDefault();
        const message = userInput.value.trim();
        
        if (message) {
            addUserMessage(message);
            userInput.value = '';
            showTypingIndicator();
            
            // Send message to C++ backend
            fetch('http://localhost:18080/api/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ message })
            })
            .then(response => response.json())
            .then(data => {
                removeTypingIndicator();
                addBotMessage(data.response);
            })
            .catch(error => {
                console.error('Error:', error);
                removeTypingIndicator();
                addBotMessage("Sorry, I'm having trouble connecting to the server. Please try again later.");
            });
        }
    }
    
    function addUserMessage(text) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message user-message';
        messageDiv.innerHTML = `
            <div class="message-content">
                <div class="message-sender">You</div>
                <div class="message-text">${text}</div>
                <div class="message-time">${getCurrentTime()}</div>
            </div>
        `;
        chatMessages.appendChild(messageDiv);
        scrollToBottom();
    }
    
    function addBotMessage(text) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message bot-message';
        messageDiv.innerHTML = `
            <div class="message-content">
                <div class="message-sender">AI Teacher</div>
                <div class="message-text">${text}</div>
                <div class="message-time">${getCurrentTime()}</div>
            </div>
        `;
        chatMessages.appendChild(messageDiv);
        scrollToBottom();
    }
    
    function showTypingIndicator() {
        const typingDiv = document.createElement('div');
        typingDiv.className = 'typing-indicator';
        typingDiv.id = 'typing-indicator';
        typingDiv.innerHTML = `
            <span class="typing-dot"></span>
            <span class="typing-dot"></span>
            <span class="typing-dot"></span>
        `;
        chatMessages.appendChild(typingDiv);
        scrollToBottom();
    }
    
    function removeTypingIndicator() {
        const typingIndicator = document.getElementById('typing-indicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
    }
    
    function toggleSpeechRecognition() {
        if (recognition) {
            if (micBtn.classList.contains('active')) {
                recognition.stop();
                micBtn.classList.remove('active');
            } else {
                recognition.start();
                micBtn.classList.add('active');
                userInput.placeholder = "Listening...";
                
                recognition.onspeechend = function() {
                    recognition.stop();
                    micBtn.classList.remove('active');
                    userInput.placeholder = "Type your question here...";
                };
            }
        }
    }
    
    function getCurrentTime() {
        const now = new Date();
        return now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
    
    function scrollToBottom() {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    // Initial scroll to bottom
    scrollToBottom();
});